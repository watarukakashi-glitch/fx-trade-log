# FX Trade Log PWA

## スマホへの入れ方（GitHub Pages使用・無料）

### 1. GitHubアカウント作成
https://github.com にアクセスしてアカウント作成

### 2. 新規リポジトリ作成
- 「New repository」をクリック
- Repository name: `fx-trade-log`
- Public にチェック
- 「Create repository」

### 3. ファイルをアップロード
- 「uploading an existing file」をクリック
- index.html / manifest.json / sw.js をドラッグ＆ドロップ
- 「Commit changes」

### 4. GitHub Pages設定
- Settings → Pages
- Source: Deploy from a branch
- Branch: main / root
- Save

### 5. URLが発行される
`https://あなたのユーザー名.github.io/fx-trade-log/`

### 6. スマホでホーム画面に追加
#### iPhone（Safari）
1. Safariで上記URLを開く
2. 下の共有ボタン（□↑）をタップ
3. 「ホーム画面に追加」

#### Android（Chrome）
1. Chromeで上記URLを開く
2. 右上の「⋮」→「ホーム画面に追加」

---

## データについて
- データはスマホのブラウザ内（localStorage）に保存されます
- アプリを削除するとデータも消えます
- 定期的にスクリーンショットか手動バックアップを推奨
